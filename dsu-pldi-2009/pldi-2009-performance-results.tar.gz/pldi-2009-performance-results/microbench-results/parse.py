#!/usr/bin/env python2.5

import re
import os

TIMING_MESSAGE = re.compile(r"""
AOS: .*\n
DSU.Message:.*\n
DSU.Message:.*\n
DSU.Message:.GC.time..nano.seconds.:.(\d+).*\n
DSU.Message:..objects.transformed:.*\n
DSU.Message:.Xformers.time..nano.seconds.:.(\d+).*\n
DSU.Message:.*\n
DSU.Message:.Update.pause.time..nano.seconds.:.(\d+).*\n
""", re.DOTALL | re.IGNORECASE | re.VERBOSE | re.MULTILINE)
FILE_NAME = re.compile(r"""run-(\d+)M-(\d+)-(\d+).txt""", re.DOTALL | re.IGNORECASE | re.VERBOSE)
HEAPSIZES = [ 80, 160, 320, 640, 1280 ]
CHANGEPERCENT = [ 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 ]
CHANGEPERCENT_FOR_LATEX = [ 0, 30, 50, 70, 100 ]
RUNS = 21

def median(values):
    assert len(values) == RUNS
    middle = (RUNS / 2)
    return sorted(values)[middle]

def Q1(values):
    return sorted(values)[len(values)/4]

def Q3(values):
    return sorted(values)[3*len(values)/4]

data = {}
for i in os.listdir('.'):
    if i.endswith('.txt'):
        match = FILE_NAME.match(i)
        assert (match is not None)
        heapsize = int(match.group(1))
        changePercent = int(match.group(2))
        run = int(match.group(3))
        contents = open(i, 'r').read()
        match = TIMING_MESSAGE.match(contents)
        if (match is not None):
            gcTime = int(match.group(1)) / 1e6
            xformTime = int(match.group(2)) / 1e6
            pauseTime = int(match.group(3)) / 1e6
            # print '%3d  %3d  %d:  %6.3f %6.3f %6.3f' % (heapsize, changePercent, run, gcTime, xformTime, pauseTime)
            data[(heapsize, changePercent, run)] = (gcTime, xformTime, pauseTime)

def printMetric(metricName, metricNumber):
    print metricName
    print '      ',
    for changePercent in CHANGEPERCENT:
        print '%6d%% ' % changePercent,
    print
    for heapsize in HEAPSIZES:
        print '%4dMB' % heapsize,
        for changePercent in CHANGEPERCENT:
            results = [ data[(heapsize, changePercent, run+1)][metricNumber] for run in xrange(RUNS) ]
            m = median(results)
            print '  %6.1f' % m,
        print

def printHeaderForLatex():
    print r'\begin{tabular}{|r|rrrrrrrrrrr|}'
    print r'Heap & \multicolumn{c}{11}{Fraction of updated objects} \\'
    print r'size',
    for changePercent in CHANGEPERCENT:
        print '&%5d\\%% ' % changePercent,
    print r'\\'

def printFooterForLatex():
    print r'\end{tabular}'

def printMetricForLatex(metricName, metricNumber):
    print r'\multicolumn{|c|}{12}{%s} \\' % metricName
    for heapsize in HEAPSIZES:
        print '%4dMB' % heapsize,
        for changePercent in CHANGEPERCENT:
            results = [ data[(heapsize, changePercent, run+1)][metricNumber] for run in xrange(RUNS) ]
            m = median(results)
            print '&  %6.1f' % m,
        print r'\\'

def jgraph(metricName, metricNumber):
    heapsize = 1280
    print 'pts'
    for changePercent in CHANGEPERCENT:
        results = [ data[(heapsize, changePercent, run+1)][metricNumber] for run in xrange(RUNS) ]
        q1 = Q1(results)
        m = median(results)
        q3 = Q3(results)
        print '%3d %6.1f %6.1f %6.1f' % (changePercent, m, q1, q3)


# printMetric('Garbage collection time (ms)', 0)
# printMetric('Running transformation functions (ms)', 1)
# printMetric('Total DSU pause time (ms)', 2)

printHeaderForLatex()
printMetricForLatex('Garbage collection time (ms)', 0)
printMetricForLatex('Running transformation functions (ms)', 1)
printMetricForLatex('Total DSU pause time (ms)', 2)
printFooterForLatex()

# jgraph(None, 0)
# jgraph(None, 1)
# jgraph(None, 2)
